require 'json'
require 'open3'
require 'fileutils'
root=File.dirname(__FILE__)
cases={
  'empty_before_colon'=>"\e[31;44;1mA\e[;38:2::10:20:30mB",
  'reveal'=>"\e[8mA\e[28mB",
  'rapid_blink'=>"\e[6mA\e[25mB",
  'double_underline'=>"\e[21mA\e[24mB",
  'incomplete_colon_rgb'=>"\e[31mA\e[38:2:1:2mB",
  'colon_rgb_trailing_fields'=>"\e[38:2::1:2:3:99mA"
}
[38,48,58].each do |command|
  [256,4294967295].each do |invalid|
    ["#{command};5;#{invalid}","#{command}:5:#{invalid}","#{command};2;#{invalid};1;2"].each_with_index do |parameter,form|
      cases["range_#{command}_#{invalid}_#{form}"]="\e[31;44;58;5;2mA\e[#{parameter};1mB"
    end
    cases["range_#{command}_#{invalid}_3"]="\e[31;44;58;5;2mA\e[#{command}:2::1:#{invalid}:2;1mB"
  end
  cases["valid_#{command}"]="\e[#{command};5;255mA\e[#{command};2;255;0;255mB\e[#{command}:5:255mC\e[#{command}:2::255:0:255mD"
end
results=[]
cases.each do |name,wire|
  folder=File.join(root,'cases',name); FileUtils.mkdir_p(folder); File.binwrite(File.join(folder,'input.bin'),wire)
  values={}
  %w[rust swift].each do |kind|
    binary = kind=='swift' && ARGV[0] ? ARGV[0] : File.join(root,kind == 'rust' ? 'rust-replay' : 'swift-baseline-replay')
    stdout,stderr,status=Open3.capture3(binary,'32','2',stdin_data:wire,binmode:true)
    raise "#{kind} #{name} failed" unless status.success?
    label=kind=='swift' && ARGV[0] ? 'swift-fixed' : kind
    File.binwrite(File.join(folder,"#{label}.json"),stdout); File.binwrite(File.join(folder,"#{label}.reply"),stderr)
    values[kind]=JSON.parse(stdout)['rows'].flat_map{|row|row['cells']}.reject{|cell|cell['text'].empty?}.map{|cell|cell.slice('text','style')}
  end
  record={name:name,pass:values['rust']==values['swift'],expected:values['rust']};results<<record
end
name=ARGV[0] ? 'fixed-results.json' : 'baseline-results.json'
File.write(File.join(root,name),JSON.pretty_generate(results)+"\n")
puts "#{results.count} cases, #{results.count{|r|r[:pass]}} matching, #{results.count{|r|!r[:pass]}} differing"
abort 'fixed SGR differential failed' if ARGV[0] && results.any? { |r| !r[:pass] }
