require 'json'
require 'open3'
require 'fileutils'
require 'digest'
root = File.dirname(__FILE__)
cases = {}
esc = "\e"
[30...38,90...98,40...48,100...108].each { |range| cases["basic_#{range.begin}"] = range.map { |n| "\e[0;#{n}mX" }.join }
cases['indexed_all'] = (0...256).map { |n| "\e[38;5;#{n};48;5;#{255-n}mX" }.join
cases['rgb_semicolon'] = [0,1,127,128,254,255].map { |n| "\e[0;38;2;#{n};#{255-n};91;48;2;27;#{n};#{255-n}mX" }.join
cases['rgb_colon'] = [0,1,127,128,254,255].map { |n| "\e[0;38:2::#{n}:#{255-n}:91;48:2:27:#{n}:#{255-n}mX" }.join
cases['style_reset'] = "\e[1;2;3;4;7;9;38;5;196mA\e[22;23;24;27;29;39mB\e[91;104mC\e[0mD"
cases['underline_color'] = "\e[4:3;58:2::12:34:56mA\e[24;59mB"
cases['palette_queries'] = (0...256).map { |n| "\e]4;#{n};?\a" }.join + "\e]10;?\a\e]11;?\e\\"
cases['palette_change'] = "\e]4;1;#123456;2;rgb:ffff/8080/0000\a\e]10;#abcdef\e\\\e]11;rgb:1/2/3\a\e]4;1;?;2;?\a\e]10;?\a\e]11;?\a\e[31mA\e[32mB\e[0mC"
cases['palette_reset'] = "\e]4;1;#123456\a\e]104;1\a\e]4;1;?\a"
cases['colon_mixed'] = "\e[38;2;20;40;60;4:3;48;5;123mA\e[0;38:2::10:20:30;1mB"
cases['empty_colon_reset'] = "\e[31;44;1mA\e[;38:2::10:20:30mB"
cases['out_of_range'] = "\e[31mA\e[38;5;256mB\e[38;2;256;0;0mC\e[38:5:256mD"
cases['conceal_reset'] = "\e[8mA\e[28mB"
results=[]
cases.each do |name,input|
  dir=File.join(root,'cases',name); FileUtils.mkdir_p(dir); File.binwrite(File.join(dir,'input.bin'),input)
  runs={}
  %w[rust swift].each do |kind|
    out,reply,status=Open3.capture3((kind == 'swift' ? File.join(root,'swift-fixed-replay') : File.join(root,'rust-replay')),'512','2',stdin_data:input,binmode:true)
    File.binwrite(File.join(dir,"#{kind}.snapshot.json"),out); File.binwrite(File.join(dir,"#{kind}.reply.bin"),reply)
    raise "#{kind} failed #{name}:#{status.exitstatus} #{reply}" unless status.success?
    doc=JSON.parse(out)
    runs[kind]={cells:doc.fetch('rows').map { |r| r.fetch('cells').map { |c| c.slice('text','kind','style') } }, palette:doc['palette'],default_fg:doc['default_fg'],default_bg:doc['default_bg'],reply:reply.unpack1('H*')}
  end
  diff=runs['rust'].keys.reject { |key| runs['rust'][key] == runs['swift'][key] }
  result={name:name,pass:diff.empty?,differing:diff}
  unless diff.empty?
    result[:first_cell_difference] = runs['rust'][:cells].flatten(1).zip(runs['swift'][:cells].flatten(1)).each_with_index.find { |(a,b),_| a != b }
  end
  results<<result; puts JSON.generate(result)
end
File.write(File.join(root,'normal-color-results.json'),JSON.pretty_generate(results)+"\n")
abort 'color differential failed' if results.any? { |r| !r[:pass] }
