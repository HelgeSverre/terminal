#include "Bridge.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static void reply(void *context, const uint8_t *bytes, size_t count) {
  (void)context;
  if (count) assert(fwrite(bytes, 1, count, stderr) == count);
}
int main(int argc, char **argv) {
  assert(argc == 3);
  Terminal *terminal = terminal_create((uint32_t)atoi(argv[1]), (uint32_t)atoi(argv[2]));
  assert(terminal);
  uint8_t buffer[65536];
  size_t count;
  while ((count = fread(buffer, 1, sizeof buffer, stdin))) {
    size_t offset = 0;
    while (offset < count || terminal_has_work(terminal)) {
      size_t used = terminal_feed(terminal, buffer + offset, count - offset, 0);
      assert(used <= count - offset);
      offset += used;
      terminal_replies(terminal, NULL, reply);
    }
  }
  terminal_finish(terminal);
  terminal_replies(terminal, NULL, reply);
  char *snapshot = terminal_snapshot(terminal, 0, 0);
  assert(snapshot);
  puts(snapshot);
  terminal_string_free(snapshot);
  terminal_destroy(terminal);
}
