import Foundation

@main enum LowercaseOracle {
  static func main() {
    var output = Data()
    for value in UInt32(0)...0x10FFFF {
      guard let scalar = Unicode.Scalar(value) else { continue }
      let mapped = Array(String(scalar).lowercased().unicodeScalars)
      if mapped.count == 1, mapped[0] == scalar { continue }
      let record = String(format: "%06X:", value) + mapped.map { String(format: "%06X", $0.value) }.joined(separator: " ") + "\n"
      output.append(contentsOf: record.utf8)
    }
    FileHandle.standardOutput.write(output)
  }
}
