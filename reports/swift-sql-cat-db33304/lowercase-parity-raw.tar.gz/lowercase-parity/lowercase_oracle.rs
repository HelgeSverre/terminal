//! Emits every non-identity Unicode scalar lowercasing mapping in the Rust
//! standard library. This is a standalone diagnostic, not product code.

use std::io::{self, Write};

fn main() -> io::Result<()> {
    eprintln!("char::UNICODE_VERSION={:?}", char::UNICODE_VERSION);
    let stdout = io::stdout();
    let mut output = io::BufWriter::new(stdout.lock());
    for value in 0..=0x10_FFFF {
        let Some(scalar) = char::from_u32(value) else {
            continue;
        };
        let mapped: Vec<_> = scalar.to_lowercase().collect();
        if mapped.len() == 1 && mapped[0] == scalar {
            continue;
        }
        write!(output, "{value:06X}:")?;
        for (index, mapped_scalar) in mapped.iter().enumerate() {
            if index != 0 {
                write!(output, " ")?;
            }
            write!(output, "{:06X}", u32::from(*mapped_scalar))?;
        }
        writeln!(output)?;
    }
    output.flush()
}
