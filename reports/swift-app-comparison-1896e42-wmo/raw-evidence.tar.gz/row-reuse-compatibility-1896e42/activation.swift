import Foundation

@main struct ReuseActivation {
  static func identity(_ row: TerminalRow) -> ObjectIdentifier {
    let storage = Mirror(reflecting: row).children.first { $0.label == "storage" }!.value
    return ObjectIdentifier(storage as AnyObject)
  }
  static func main() throws {
    var results: [String: Bool] = [:]
    var wrapped = TerminalDocument(columns: 2, rows: 1)
    let initial = identity(wrapped.alternate.rows[0])
    _ = wrapped.print(Array("ABC".unicodeScalars), usingAlternate: true,
                      leftRightMargins: false, autoWrap: true, insertMode: false,
                      attributes: .init(style: TerminalStyle(), link: nil, protected: false))
    results["one_wrap_reuses_storage"] = identity(wrapped.alternate.rows[0]) == initial
    for reverse in [false, true] {
      var indexed = TerminalDocument(columns: 2, rows: 1)
      let initial = identity(indexed.alternate.rows[0])
      _ = indexed.index(usingAlternate: true, reverse: reverse,
                        leftRightMargins: false, eraseStyle: TerminalStyle())
      results[reverse ? "one_ri_reuses_storage" : "one_lf_reuses_storage"] = identity(indexed.alternate.rows[0]) == initial
    }
    let data = try JSONSerialization.data(withJSONObject: results, options: [.sortedKeys])
    print(String(decoding: data, as: UTF8.self))
    exit(results.values.allSatisfy { $0 } ? 0 : 3)
  }
}
