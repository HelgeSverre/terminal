# frozen_string_literal: true
require 'digest'
require 'json'
require 'fileutils'
require '/Users/helge/code/terminal/tools/native_smoke'
abort 'Usage: terminal-final-native.rb APP SOURCE_SHA NEW_OUTPUT' unless ARGV.length == 3
app, source, directory = ARGV
app = File.realpath(app)
executable = File.join(app, 'Contents/MacOS/Terminal')
directory = File.expand_path(directory)
abort 'Choose a fresh output directory' if File.exist?(directory)
FileUtils.mkdir_p(directory)
FileUtils.cp(__FILE__, File.join(directory, 'runner.rb'))
results = []
provenance = { source_commit: source, app: app,
  executable_sha256: Digest::SHA256.file(executable).hexdigest,
  runner_sha256: Digest::SHA256.file(__FILE__).hexdigest, tests: results, passed: false }
Signal.trap('TERM') { raise Interrupt, 'Final native run terminated' }
Signal.trap('INT') { raise Interrupt, 'Final native run interrupted' }
run = lambda do |name, arguments, timeout|
  report = File.join(directory, "#{name}.json")
  record = { name: name, passed: false }
  process = nil
  begin
    process = NativeSmokeProcess.new([executable, *arguments.call(report)], log: File.join(directory, "#{name}.log"))
    record[:pid] = process.pid
    state = process.wait(timeout)
    raise 'App did not exit successfully' unless state&.success?
    raise 'App left owned descendants' unless process.live_pids.empty?
    data = JSON.parse(File.read(report))
if name.start_with?('close-')
  expected = name == 'close-window' ? 'last-window-close' : 'cmd+q'
  child = data.fetch('child_pid')
  raise 'Wrong close trigger or child identity' unless data.fetch('trigger') == expected && child.is_a?(Integer) && child.positive?
  begin
    Process.kill(0, child)
    raise 'PTY child survived app shutdown'
  rescue Errno::ESRCH
  end
  data.merge!('passed' => true, 'app_exited' => true, 'child_exited' => true)
  File.write(report, JSON.pretty_generate(data) + "\n")
end
raise 'Native assertions failed' unless data.fetch('passed')
    record[:passed] = true
    record[:natural_exit] = true
    puts "PASS #{name}"
  rescue StandardError, Interrupt => error
    record[:failure] = "#{error.class}: #{error.message}"
    raise
  ensure
    record[:cleanup_survivors] = process ? process.cleanup : []
    record[:passed] = false unless record[:cleanup_survivors].empty?
    results << record
    File.write(File.join(directory, 'provenance.json'), JSON.pretty_generate(provenance) + "\n")
  end
end
begin
  run.call('native', ->(p) { ['--self-test', p] }, 40)
  run.call('editing', ->(p) { ['--editing-smoke', p] }, 40)
  geometry = ['--columns', '100', '--rows', '36', '--font-size', '14']
  run.call('glyph', ->(p) { ['--glyph-smoke', p, *geometry] }, 80)
  run.call('atlas', ->(p) { ['--glyph-smoke', p, '--atlas-pressure-smoke', *geometry] }, 55)
  run.call('atlas-budget', ->(p) { ['--glyph-smoke', p, '--atlas-pressure-smoke', '--atlas-fallback-budget-smoke', *geometry] }, 55)
  %w[window shortcut].each do |mode|
    run.call("close-#{mode}", ->(p) { ['--close-smoke', p, *(mode == 'shortcut' ? ['--quit-shortcut'] : []),
      '--execute', '/bin/sh', '-c', "trap '' HUP; printf CLOSE_SMOKE_READY; exec /bin/sleep 30"] }, 12)
  end
  player = '/Users/helge/code/myself/dmscene/build/native-player/hakkuh'
  demo = '/Users/helge/code/myself/dmscene/demos/hakkuh.dmt'
  raise 'Missing local dmscene player or fixture' unless File.executable?(player) && File.file?(demo)
  raise 'Could not mute macOS output before demo' unless system('/usr/bin/osascript', '-e', 'set volume output muted true')
  provenance[:macos_output_muted_before_demo] = true
  run.call('dmscene-kitty-960', ->(p) { ['--demo-smoke', p, '--execute', player, 'play', demo,
    '--graphics', 'kitty', '--size', '960x600', '--fps', '30', '--mute'] }, 30)
  provenance[:passed] = results.all? { |record| record[:passed] }
ensure
  File.write(File.join(directory, 'provenance.json'), JSON.pretty_generate(provenance) + "\n")
end
abort 'Final native verification failed' unless provenance[:passed]
