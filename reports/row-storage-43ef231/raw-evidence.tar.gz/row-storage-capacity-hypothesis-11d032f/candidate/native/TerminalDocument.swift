import Foundation

// `TerminalCell` is the public/read projection of a terminal cell.  Rows do
// not retain one of these for every column: a String (and its ARC traffic) is
// far too expensive for the overwhelmingly scalar, blank grid.
struct TerminalStyle: Equatable {
  var foreground: UInt32 = 0; var background: UInt32 = 0; var underline: UInt32 = 0
  var flags: UInt16 = 0; var underlineKind: UInt8 = 0
  func erased() -> TerminalStyle { TerminalStyle(background: background) }
}
struct TerminalCell: Equatable {
  // 0 empty, 1 single-width lead, 2 double-width lead, 3 continuation,
  // 4 a single-column spacer left by a wide glyph that wrapped.
  var text = ""; var kind: UInt8 = 0; var style = TerminalStyle(); var link: String?
  var flags: UInt8 = 0; var protected = false
  static func erased(_ style: TerminalStyle = TerminalStyle()) -> TerminalCell {
    TerminalCell(text: "", kind: 0, style: style.erased())
  }
}

// The hot row representation.  Keep this deliberately reference-free: text
// is either the single Unicode scalar here, or an exceptional payload in the
// row dictionary below. `hasScalar` distinguishes a real U+0000 from empty.
private struct TerminalRowSlot: Equatable {
  var scalar: UInt32 = 0
  var style = TerminalStyle()
  var hasScalar = false
  var kind: UInt8 = 0
  var flags: UInt8 = 0
  var protected = false
}

private struct TerminalRowPayload: Equatable {
  var text: String?
  var link: String?
}

// Matches the old TerminalCell ABI stride without retaining a String, link,
// or style. It is used only to reproduce Array's old capacity rounding for
// the public history-byte budget; it is never row storage.
private struct TerminalLegacyCapacityCell {
  var a: UInt64 = 0; var b: UInt64 = 0; var c: UInt64 = 0; var d: UInt64 = 0
  var e: UInt64 = 0; var f: UInt64 = 0; var g: UInt64 = 0; var h: UInt64 = 0
}

struct TerminalRow: Equatable {
  var id: UInt64; var revision: UInt64; var softWrapped = false
  private var slots: [TerminalRowSlot]
  // `slots.capacity` is deliberately not the history contract: Swift rounds
  // Array capacity by element stride. Preserve the former 64-byte rich-cell
  // capacity independently without retaining a parallel rich-cell grid.
  private var logicalCellCapacity: Int
  // Sparse by construction: entries are removed on overwrite/erase and never
  // outnumber physical columns. Values are copied with their row snapshots.
  private var payloads: [Int: TerminalRowPayload] = [:]

  init(id: UInt64 = 0, revision: UInt64 = 0, cells: [TerminalCell]) {
    self.id = id; self.revision = revision
    self.slots = []
    // Keep the old array-capacity budget observable to history admission when
    // a caller supplies a deliberately over-reserved rich fixture.
    self.slots.reserveCapacity(cells.capacity)
    self.slots.append(contentsOf: repeatElement(TerminalRowSlot(), count: cells.count))
    self.logicalCellCapacity = cells.capacity
    for (index, cell) in cells.enumerated() { setCell(cell, at: index) }
  }
  init(columns: Int, logicalCellCapacity: Int? = nil) {
    id = 0; revision = 0
    slots = Array(repeating: TerminalRowSlot(), count: columns)
    self.logicalCellCapacity = logicalCellCapacity ?? Self.blankLogicalCapacity(columns: columns)
  }

  // Read-only rich projection for publication, search, and compatibility at
  // the Core boundary. It retains value/COW snapshots of the two stores and
  // constructs a cell only for the requested subscript; editing must use the
  // narrow operations below and never retain this projection across mutation.
  struct Cells: RandomAccessCollection {
    typealias Index = Int
    typealias Element = TerminalCell
    private let slots: [TerminalRowSlot]
    private let payloads: [Int: TerminalRowPayload]
    fileprivate init(slots: [TerminalRowSlot], payloads: [Int: TerminalRowPayload]) {
      self.slots = slots; self.payloads = payloads
    }
    var startIndex: Int { slots.startIndex }
    var endIndex: Int { slots.endIndex }
    subscript(position: Int) -> TerminalCell {
      TerminalRow.project(slots[position], payloads[position])
    }
  }
  var cells: Cells { Cells(slots: slots, payloads: payloads) }
  var count: Int { slots.count }
  var payloadCount: Int { payloads.count }
  var retainedCellCapacity: Int { logicalCellCapacity }

  func cell(_ index: Int) -> TerminalCell {
    Self.project(slots[index], payloads[index])
  }
  private static func project(_ slot: TerminalRowSlot, _ payload: TerminalRowPayload?) -> TerminalCell {
    let text: String
    if let payloadText = payload?.text { text = payloadText }
    else if slot.hasScalar, let scalar = Unicode.Scalar(slot.scalar) { text = String(scalar) }
    else { text = "" }
    return TerminalCell(text: text, kind: slot.kind, style: slot.style,
                        link: payload?.link, flags: slot.flags, protected: slot.protected)
  }

  mutating func setCell(_ cell: TerminalCell, at index: Int) {
    var slot = TerminalRowSlot(scalar: 0, style: cell.style, hasScalar: false,
                               kind: cell.kind, flags: cell.flags, protected: cell.protected)
    var payload = TerminalRowPayload(text: nil, link: cell.link)
    let scalars = cell.text.unicodeScalars
    if scalars.count == 1, let scalar = scalars.first {
      slot.scalar = scalar.value
      slot.hasScalar = true
    } else if !cell.text.isEmpty {
      payload.text = cell.text
    }
    slots[index] = slot
    if payload.text != nil || payload.link != nil { payloads[index] = payload }
    else { payloads.removeValue(forKey: index) }
  }

  mutating func setScalar(_ scalar: Unicode.Scalar, at index: Int, kind: UInt8,
                          style: TerminalStyle, link: String?, flags: UInt8, protected: Bool) {
    slots[index] = TerminalRowSlot(scalar: scalar.value, style: style, hasScalar: true,
                                   kind: kind, flags: flags, protected: protected)
    if let link { payloads[index] = TerminalRowPayload(text: nil, link: link) }
    else { payloads.removeValue(forKey: index) }
  }

  mutating func erase(at index: Int, style: TerminalStyle = TerminalStyle()) {
    slots[index] = TerminalRowSlot(style: style.erased())
    payloads.removeValue(forKey: index)
  }
  mutating func copyCell(from source: TerminalRow, at sourceIndex: Int, to index: Int) {
    slots[index] = source.slots[sourceIndex]
    if let payload = source.payloads[sourceIndex] { payloads[index] = payload }
    else { payloads.removeValue(forKey: index) }
  }
  mutating func setKind(_ kind: UInt8, at index: Int) { slots[index].kind = kind }
  mutating func setFlags(_ flags: UInt8, at index: Int) { slots[index].flags = flags }
  mutating func addFlags(_ flags: UInt8, at index: Int) { slots[index].flags |= flags }
  mutating func clearText(at index: Int) {
    slots[index].scalar = 0
    slots[index].hasScalar = false
    if var payload = payloads[index] {
      payload.text = nil
      if payload.link != nil { payloads[index] = payload }
      else { payloads.removeValue(forKey: index) }
    }
  }
  func kind(at index: Int) -> UInt8 { slots[index].kind }
  func flags(at index: Int) -> UInt8 { slots[index].flags }
  func style(at index: Int) -> TerminalStyle { slots[index].style }
  func isProtected(at index: Int) -> Bool { slots[index].protected }
  func scalarCount(at index: Int) -> Int {
    payloads[index]?.text?.unicodeScalars.count ?? (slots[index].hasScalar ? 1 : 0)
  }
  mutating func appendScalar(_ scalar: Unicode.Scalar, at index: Int) {
    var cell = cell(index)
    cell.text.unicodeScalars.append(scalar)
    setCell(cell, at: index)
  }
  mutating func truncate(to newCount: Int) {
    logicalCellCapacity = Self.legacyCapacity(existingCount: slots.count,
                                               capacity: logicalCellCapacity,
                                               truncatingTo: newCount)
    slots = Array(slots.prefix(newCount))
    payloads = payloads.reduce(into: [:]) { result, entry in
      if entry.key < newCount { result[entry.key] = entry.value }
    }
  }
  mutating func appendBlanks(_ count: Int) {
    guard count > 0 else { return }
    logicalCellCapacity = Self.legacyCapacity(existingCount: slots.count,
                                               capacity: logicalCellCapacity,
                                               appending: count)
    slots.append(contentsOf: repeatElement(TerminalRowSlot(), count: count))
  }
  mutating func copyRange(from source: TerminalRow, _ range: ClosedRange<Int>) {
    for index in range { copyCell(from: source, at: index, to: index) }
  }

  // Preserve the published history-byte contract across this physical storage
  // optimization. These are the old ABI strides (row 32, rich cell 64), not
  // an allocator or RSS estimate; payload bytes retain their old per-cell
  // ownership semantics.
  private static let logicalRowCharge: UInt64 = 32
  private static let logicalCellCharge: UInt64 = 64
  var retainedStorageCost: UInt64 {
    var bytes = Self.logicalRowCharge + UInt64(slots.capacity) * Self.logicalCellCharge
    for index in slots.indices {
      if let text = payloads[index]?.text { bytes += UInt64(text.utf8.count) }
      else if slots[index].hasScalar, let scalar = Unicode.Scalar(slots[index].scalar) {
        bytes += UInt64(String(scalar).utf8.count)
      }
      if let link = payloads[index]?.link { bytes += UInt64(link.utf8.count) }
    }
    return bytes
  }

  // Called once per document geometry (or by a direct test fixture), never by
  // normal blank-row allocation. That keeps the row hot path reference-free
  // and avoids a temporary 64-byte-per-column calibration array per scroll.
  static func blankLogicalCapacity(columns count: Int) -> Int {
    Array(repeating: TerminalLegacyCapacityCell(), count: count).capacity
  }
  private static func legacySeed(count: Int, capacity: Int) -> [TerminalLegacyCapacityCell] {
    var cells: [TerminalLegacyCapacityCell] = []
    cells.reserveCapacity(capacity)
    cells.append(contentsOf: repeatElement(TerminalLegacyCapacityCell(), count: count))
    return cells
  }
  private static func legacyCapacity(existingCount: Int, capacity: Int, truncatingTo count: Int) -> Int {
    Array(legacySeed(count: existingCount, capacity: capacity).prefix(count)).capacity
  }
  private static func legacyCapacity(existingCount: Int, capacity: Int, appending count: Int) -> Int {
    var cells = legacySeed(count: existingCount, capacity: capacity)
    cells.append(contentsOf: repeatElement(TerminalLegacyCapacityCell(), count: count))
    return cells.capacity
  }

  static func == (lhs: TerminalRow, rhs: TerminalRow) -> Bool {
    guard lhs.id == rhs.id, lhs.revision == rhs.revision,
          lhs.softWrapped == rhs.softWrapped, lhs.slots.count == rhs.slots.count else { return false }
    // Most comparisons preserve representation, so avoid projecting strings.
    if lhs.slots == rhs.slots && lhs.payloads == rhs.payloads { return true }
    // String equality is canonically equivalent; a scalar slot and an
    // exceptional multi-scalar payload can therefore be semantically equal.
    for index in lhs.slots.indices where lhs.cell(index) != rhs.cell(index) { return false }
    return true
  }
}
struct PromptAnchor: Equatable {
  var row: UInt64
  var column: Int
  var pendingWrap: Bool
}
struct TerminalScreen: Equatable {
  enum PromptPhase { case none, drawing, inputReady }
  var rows: [TerminalRow]; var cursorRow = 0; var cursorColumn = 0; var pendingWrap = false
  var savedRow = 0; var savedColumn = 0; var savedPendingWrap = false; var savedOrigin = false
  var savedStyle = TerminalStyle(); var savedLink: String?
  var keyboardFlags: UInt32 = 0
  // OSC 133 prompt identity is screen-local and survives resize by row ID.
  var promptPhase = PromptPhase.none
  var atPrompt: Bool { promptPhase != .none }
  var inputReady: Bool { promptPhase == .inputReady }
  var promptRedraw = false
  var promptAnchor: PromptAnchor?
  // A geometry-dependent row address can expire while the shell is still
  // editing the same command. Only OSC 133 changes that semantic phase.
  mutating func retirePromptAnchor() { promptAnchor = nil; promptRedraw = false }
  var topMargin: Int; var bottomMargin: Int; var leftMargin: Int; var rightMargin: Int
  init(rows: [TerminalRow], columns: Int) {
    self.rows = rows; topMargin = 0; bottomMargin = max(0, rows.count - 1)
    leftMargin = 0; rightMargin = max(0, columns - 1)
  }
  init(columns: Int, rows count: Int) {
    let capacity = TerminalRow.blankLogicalCapacity(columns: columns)
    self.init(rows: Array(repeating: TerminalRow(columns: columns, logicalCellCapacity: capacity), count: count), columns: columns)
  }
}
struct TerminalDocument {
  struct PrintAttributes {
    var style: TerminalStyle
    var link: String?
    var protected: Bool
  }
  struct PrintEffect {
    var appendedHistory: [TerminalRow]
    var lastPrinted: String?
    var repeatAttributes: PrintAttributes?
  }
  struct PrintBatchEffect {
    var effect: PrintEffect
    var consumedScalarCount: Int
    var mutationCount: Int
  }
  // All state needed to continue a grapheme across decoder batches lives in
  // one value.  Keeping it disjoint from the selected screen lets the batch
  // writer hold that screen exactly once without accidentally extending an
  // inout row borrow across a wrap or scroll.
  private struct PrintState {
    var segmenter = SwiftUnicode.Segmenter()
    var openCluster: (row: Int, column: Int)?
    var retainedScalars = 0
    var capped = false

    mutating func reset() {
      segmenter = SwiftUnicode.Segmenter()
      openCluster = nil
      retainedScalars = 0
      capped = false
    }
  }
  private(set) var columns: Int; private(set) var rowCount: Int
  private var blankCellCapacity: Int
  var history: [TerminalRow] = []; var primary: TerminalScreen; var alternate: TerminalScreen
  fileprivate var nextRowID: UInt64 = 1
  // Print/segmentation state belongs beside the cells it identifies. This
  // keeps the scalar transaction self-contained across cursor/edit resets.
  private var printState = PrintState()
  init(columns: Int, rows: Int) {
    self.columns = columns; rowCount = rows
    blankCellCapacity = TerminalRow.blankLogicalCapacity(columns: columns)
    primary = TerminalScreen(rows: [], columns: columns); alternate = TerminalScreen(rows: [], columns: columns)
    primary.rows = makeRows(rows); alternate.rows = makeRows(rows)
    primary.bottomMargin = rows - 1; alternate.bottomMargin = rows - 1
  }
  mutating func blankRow() -> TerminalRow {
    defer { nextRowID &+= 1 }
    var row = TerminalRow(columns: columns, logicalCellCapacity: blankCellCapacity); row.id = nextRowID; return row
  }
  mutating func eraseRow(_ style: TerminalStyle) -> TerminalRow {
    var row = blankRow()
    for column in 0..<columns { row.erase(at: column, style: style) }
    return row
  }
  mutating func setSize(columns: Int, rows: Int) {
    if self.columns != columns { blankCellCapacity = TerminalRow.blankLogicalCapacity(columns: columns) }
    self.columns = columns; rowCount = rows
  }

  mutating func resetPrintCluster() {
    printState.reset()
  }

  // LF/IND/RI select and mutate their screen here so callers do not need to
  // materialize a whole screen value merely to alter its cursor or rows.
  // The returned row is the only one eligible for primary history retention.
  mutating func index(usingAlternate: Bool, reverse: Bool,
                      leftRightMargins: Bool, eraseStyle: TerminalStyle) -> [TerminalRow] {
    if usingAlternate {
      _ = Self.index(&alternate, columns: columns, reverse: reverse,
                     leftRightMargins: leftRightMargins, eraseStyle: eraseStyle,
                     nextRowID: &nextRowID)
      return []
    }
    guard let removed = Self.index(&primary, columns: columns, reverse: reverse,
                                   leftRightMargins: leftRightMargins, eraseStyle: eraseStyle,
                                   nextRowID: &nextRowID) else { return [] }
    history.append(removed)
    return [removed]
  }

  private static func index(_ screen: inout TerminalScreen, columns: Int,
                            reverse: Bool, leftRightMargins: Bool,
                            eraseStyle: TerminalStyle, nextRowID: inout UInt64) -> TerminalRow? {
    let horizontal = leftRightMargins ? (screen.leftMargin, screen.rightMargin) : (0, columns - 1)
    let inside = (horizontal.0...horizontal.1).contains(screen.cursorColumn)
    screen.pendingWrap = false
    if reverse {
      if screen.cursorRow == screen.topMargin && inside {
        _ = scrollForIndex(&screen, columns: columns, top: screen.topMargin, bottom: screen.bottomMargin,
                           left: horizontal.0, right: horizontal.1, up: false, eraseStyle: eraseStyle,
                           nextRowID: &nextRowID)
      } else {
        screen.cursorRow = max(0, screen.cursorRow - 1)
      }
    } else if screen.cursorRow == screen.bottomMargin && inside {
      return scrollForIndex(&screen, columns: columns, top: screen.topMargin, bottom: screen.bottomMargin,
                            left: horizontal.0, right: horizontal.1, up: true, eraseStyle: eraseStyle,
                            nextRowID: &nextRowID)
    } else {
      screen.cursorRow = min(screen.rows.count - 1, screen.cursorRow + 1)
    }
    return nil
  }

  private static func scrollForIndex(_ screen: inout TerminalScreen, columns: Int,
                                     top: Int, bottom: Int, left: Int, right: Int, up: Bool,
                                     eraseStyle: TerminalStyle, nextRowID: inout UInt64) -> TerminalRow? {
    guard top >= 0, bottom < screen.rows.count, top <= bottom else { return nil }
    if left != 0 || right != columns - 1 {
      scrollRectangleInPlace(&screen, columns: columns, top: top, bottom: bottom,
                             left: left, right: right, count: 1, up: up, eraseStyle: eraseStyle)
      return nil
    }
    let removed = screen.rows.remove(at: up ? top : bottom)
    var replacement = TerminalRow(columns: columns,
                                  logicalCellCapacity: screen.rows.first?.retainedCellCapacity ?? TerminalRow.blankLogicalCapacity(columns: columns))
    replacement.id = nextRowID
    for column in 0..<columns { replacement.erase(at: column, style: eraseStyle) }
    nextRowID &+= 1
    screen.rows.insert(replacement, at: up ? bottom : top)
    return up && top == 0 && bottom == screen.rows.count - 1 ? removed : nil
  }

  // This is the document's scalar-print transaction. It is intentionally a
  // terminal operation rather than a generic mutable-grid callback: callers
  // provide parser/mode facts, while this module owns segmentation, cells,
  // continuation repair, cursor/wrap, history rows, identities and retention.
  mutating func print(_ scalar: Unicode.Scalar,
                      usingAlternate: Bool, leftRightMargins: Bool,
                      autoWrap: Bool, insertMode: Bool,
                      attributes: PrintAttributes) -> PrintEffect? {
    let batch = print(CollectionOfOne(scalar), usingAlternate: usingAlternate,
                      leftRightMargins: leftRightMargins, autoWrap: autoWrap,
                      insertMode: insertMode, attributes: attributes)
    return batch.mutationCount == 0 ? nil : batch.effect
  }

  // Bounded text transaction for the ordinary decoder path. It deliberately
  // stops after a row replacement: IDs/history must become visible to Core
  // before the next scalar can scroll again.
  mutating func print<C: Collection>(_ scalars: C, usingAlternate: Bool,
                      leftRightMargins: Bool, autoWrap: Bool, insertMode: Bool,
                      attributes: borrowing PrintAttributes) -> PrintBatchEffect where C.Element == Unicode.Scalar {
    if usingAlternate {
      return Self.printBatch(scalars, in: &alternate, columns: columns,
                             leftRightMargins: leftRightMargins, autoWrap: autoWrap,
                             insertMode: insertMode, attributes: attributes, history: &history,
                             retainHistory: false, state: &printState, nextRowID: &nextRowID)
    }
    return Self.printBatch(scalars, in: &primary, columns: columns,
                           leftRightMargins: leftRightMargins, autoWrap: autoWrap,
                           insertMode: insertMode, attributes: attributes, history: &history,
                           retainHistory: true, state: &printState, nextRowID: &nextRowID)
  }

  private static func category(for scalar: Unicode.Scalar) -> SwiftUnicode.Category {
    switch scalar.value {
    case 0x000d: return .cr
    case 0x000a: return .lf
    case 0x0000...0x001f, 0x007f: return .control
    case 0x0000...0x007f: return .other
    default: return SwiftUnicode.category(of: scalar)
    }
  }

  private static func printBatch<C: Collection>(_ scalars: C, in screen: inout TerminalScreen,
                                                columns: Int, leftRightMargins: Bool,
                                                autoWrap: Bool, insertMode: Bool,
                                                attributes: borrowing PrintAttributes,
                                                history: inout [TerminalRow], retainHistory: Bool,
                                                state: inout PrintState,
                                                nextRowID: inout UInt64) -> PrintBatchEffect
  where C.Element == Unicode.Scalar {
    var appended: [TerminalRow] = []
    var replacements: [Int] = []
    var effect = PrintEffect(appendedHistory: [], lastPrinted: nil, repeatAttributes: nil)
    var consumed = 0, mutations = 0
    var index = scalars.startIndex
    while index != scalars.endIndex {
      let scalar = scalars[index]
      index = scalars.index(after: index)
      consumed += 1
      let category = category(for: scalar)
      switch category { case .control, .cr, .lf: continue; default: break }
      let startsCluster = state.segmenter.push(scalar, category: category)
      if SwiftUnicode.isDefaultIgnorable(scalar) {
        if startsCluster || !hasExtendablePrintOwner(state.openCluster, in: screen) {
          state.reset()
          continue
        }
      }
      Self.print(scalar, category: category, startsCluster: startsCluster, in: &screen, columns: columns,
                 leftRightMargins: leftRightMargins, autoWrap: autoWrap, insertMode: insertMode,
                 attributes: attributes, history: &appended, replacementRows: &replacements,
                 retainHistory: retainHistory, state: &state, effect: &effect)
      mutations += 1
      // A replacement has no identity while the row is being edited. Install
      // it before Core can admit a further scalar (which may scroll again).
      if !replacements.isEmpty || !appended.isEmpty {
        assignRowIDs(&screen, at: replacements, nextRowID: &nextRowID)
        if retainHistory { history.append(contentsOf: appended) }
        effect.appendedHistory = appended
        return PrintBatchEffect(effect: effect, consumedScalarCount: consumed, mutationCount: mutations)
      }

      // Admission remains deliberately narrow: the first scalar has already
      // established grapheme ownership through the ordinary transaction.
      // Subsequent printable ASCII scalars each begin a fresh cluster, so a
      // bounded same-row run can share one row replacement without altering
      // wrapping, insert, history or identity boundaries.
      guard category == .other, scalar.value >= 0x20, scalar.value <= 0x7e,
            startsCluster, !insertMode, !screen.pendingWrap,
            screen.rows.indices.contains(screen.cursorRow),
            screen.rows[screen.cursorRow].count > screen.cursorColumn else { continue }
      let horizontal = leftRightMargins
        ? (screen.leftMargin, screen.rightMargin) : (0, columns - 1)
      let bounds = screen.cursorColumn <= horizontal.1 ? horizontal : (0, columns - 1)
      let capacity = autoWrap ? bounds.1 - screen.cursorColumn + 1
                              : bounds.1 - screen.cursorColumn
      guard capacity > 0, index != scalars.endIndex else { continue }

      var end = index
      var count = 0
      var last: Unicode.Scalar?
      while end != scalars.endIndex, count < capacity {
        let candidate = scalars[end]
        guard candidate.value >= 0x20, candidate.value <= 0x7e else { break }
        last = candidate
        count += 1
        end = scalars.index(after: end)
      }
      guard count > 0, let last else { continue }

      // Segmenter state after a run of plain ASCII depends only on its final
      // scalar. Work on a copy so an unexpected continuation retains the
      // ordinary scalar path rather than changing state prematurely.
      var finalSegmenter = state.segmenter
      guard finalSegmenter.push(last, category: .other) else { continue }
      Self.replacePrintedASCII(in: &screen.rows[screen.cursorRow], at: screen.cursorColumn,
                               scalars: scalars[index..<end], count: count,
                               attributes: attributes)
      state.segmenter = finalSegmenter
      let firstColumn = screen.cursorColumn
      state.openCluster = (screen.cursorRow, firstColumn + count - 1)
      state.retainedScalars = 1
      state.capped = false
      effect.lastPrinted = String(last)
      effect.repeatAttributes = PrintAttributes(style: attributes.style, link: attributes.link,
                                                protected: attributes.protected)
      screen.cursorColumn = min(bounds.1, firstColumn + count)
      screen.pendingWrap = firstColumn + count > bounds.1 && autoWrap
      consumed += count
      mutations += count
      index = end
    }
    effect.appendedHistory = appended
    return PrintBatchEffect(effect: effect, consumedScalarCount: consumed, mutationCount: mutations)
  }

  private static func hasExtendablePrintOwner(_ owner: (row: Int, column: Int)?,
                                                in screen: borrowing TerminalScreen) -> Bool {
    guard let owner else { return false }
    return owner.row == screen.cursorRow && screen.rows.indices.contains(owner.row) &&
      screen.rows[owner.row].count > owner.column
  }

  private static func assignRowIDs(_ screen: inout TerminalScreen, at indices: [Int], nextRowID: inout UInt64) {
    for index in indices where screen.rows.indices.contains(index) {
      // The placeholder is installed while the selected screen is held
      // inout; allocating its identity afterwards avoids a temporary screen
      // copy and makes row allocation explicit at the ownership seam.
      screen.rows[index].id = nextRowID
      nextRowID &+= 1
    }
  }

  private static func print(_ scalar: Unicode.Scalar, category: SwiftUnicode.Category, startsCluster: Bool,
                            in screen: inout TerminalScreen, columns: Int,
                            leftRightMargins: Bool, autoWrap: Bool, insertMode: Bool,
                            attributes: borrowing PrintAttributes, history: inout [TerminalRow],
                            replacementRows: inout [Int], retainHistory: Bool,
                            state: inout PrintState,
                            effect: inout PrintEffect) {
    let horizontal = leftRightMargins ? (screen.leftMargin, screen.rightMargin) : (0, columns - 1)
    func writeBounds(_ column: Int) -> (left: Int, right: Int) {
      return column <= horizontal.1 ? (horizontal.0, horizontal.1) : (0, columns - 1)
    }
    func erase(_ row: Int, _ range: Range<Int>, _ eraseStyle: TerminalStyle) {
      let lower = max(0, range.lowerBound), upper = min(columns, range.upperBound)
      guard screen.rows.indices.contains(row), lower < upper else { return }
      for column in lower..<upper { screen.rows[row].erase(at: column, style: eraseStyle) }
      Self.repairWidePairsInPlace(&screen.rows[row], around: lower..<upper, eraseStyle: eraseStyle)
      screen.rows[row].revision &+= 1
    }
    func shift(_ row: Int, _ column: Int, _ right: Int, _ amount: Int, _ eraseStyle: TerminalStyle) {
      guard screen.rows.indices.contains(row), column <= right else { return }
      let count = min(amount, right - column + 1)
      guard count > 0 else { return }
      if column + count <= right {
        let source = screen.rows[row]
        for destination in stride(from: right, through: column + count, by: -1) {
          screen.rows[row].copyCell(from: source, at: destination - count, to: destination)
        }
      }
      for index in column..<(column + count) { screen.rows[row].erase(at: index, style: eraseStyle) }
      Self.repairWidePairsInPlace(&screen.rows[row], around: column..<(right + 1), eraseStyle: eraseStyle)
      screen.rows[row].revision &+= 1
    }
    func scrollUpFullWidth() {
      let removed = screen.rows.remove(at: screen.topMargin)
      var replacement = TerminalRow(columns: columns,
                                    logicalCellCapacity: screen.rows.first?.retainedCellCapacity ?? TerminalRow.blankLogicalCapacity(columns: columns))
      for column in 0..<columns { replacement.erase(at: column, style: attributes.style) }
      screen.rows.insert(replacement, at: screen.bottomMargin)
      replacementRows.append(screen.bottomMargin)
      if retainHistory && screen.topMargin == 0 && screen.bottomMargin == screen.rows.count - 1 {
        history.append(removed)
      }
    }
    func wrap() {
      let old = screen.cursorRow
      screen.rows[old].softWrapped = horizontal.0 == 0 && horizontal.1 == columns - 1
      let inside = (horizontal.0...horizontal.1).contains(screen.cursorColumn)
      if screen.cursorRow == screen.bottomMargin && inside {
        if horizontal.0 == 0 && horizontal.1 == columns - 1 {
          scrollUpFullWidth()
        } else {
          Self.scrollRectangleInPlace(&screen, columns: columns, top: screen.topMargin, bottom: screen.bottomMargin,
                                      left: horizontal.0, right: horizontal.1, count: 1,
                               up: true, eraseStyle: attributes.style)
        }
      } else {
        screen.cursorRow = min(screen.rows.count - 1, screen.cursorRow + 1)
      }
      screen.cursorColumn = writeBounds(screen.cursorColumn).left
      screen.pendingWrap = false
    }

    if !startsCluster, let owner = state.openCluster, owner.row == screen.cursorRow,
       screen.rows[owner.row].count > owner.column {
      let cell = screen.rows[owner.row].cell(owner.column)
      if state.capped || state.retainedScalars + 1 > 64 {
        state.capped = true
        screen.rows[owner.row].addFlags(4, at: owner.column)
        return
      }
      state.retainedScalars += 1
      var combined = cell.text
      combined.unicodeScalars.append(scalar)
      let nominal = min(2, max(1, SwiftUnicode.cellWidth(of: combined)))
      let oldWidth = cell.kind == 2 ? 2 : 1
      let right = writeBounds(owner.column).right
      if nominal > oldWidth && owner.column + nominal > right + 1 && autoWrap {
        erase(owner.row, owner.column..<(owner.column + oldWidth), cell.style.erased())
        if writeBounds(owner.column).left == 0 && right == columns - 1 { screen.rows[owner.row].setKind(4, at: owner.column) }
        screen.cursorRow = owner.row; screen.cursorColumn = owner.column; screen.pendingWrap = true
        wrap()
        let row = screen.cursorRow, column = screen.cursorColumn
        let newRight = writeBounds(column).right
        let occupied = min(nominal, newRight + 1 - column)
        let lead = TerminalCell(text: combined, kind: nominal == 2 && occupied == 2 ? 2 : 1,
                                style: cell.style, link: cell.link,
                                flags: cell.flags | (nominal > occupied ? 1 : 0),
                                protected: cell.protected)
        Self.replacePrintedLead(in: &screen.rows[row], at: column, with: lead)
        state.openCluster = (row, column)
        screen.cursorColumn = min(newRight, column + occupied); screen.pendingWrap = column + occupied > newRight && autoWrap
      } else {
        let occupied = min(nominal, right + 1 - owner.column)
        if occupied > oldWidth && insertMode && (horizontal.0...horizontal.1).contains(owner.column) {
          shift(owner.row, owner.column + oldWidth, horizontal.1, occupied - oldWidth, cell.style.erased())
        }
        let lead = TerminalCell(text: combined, kind: nominal == 2 && occupied == 2 ? 2 : 1,
                                style: cell.style, link: cell.link,
                                flags: cell.flags | (nominal > occupied ? 1 : 0),
                                protected: cell.protected)
        Self.replacePrintedLead(in: &screen.rows[owner.row], at: owner.column, with: lead)
        screen.cursorRow = owner.row; screen.cursorColumn = min(right, owner.column + occupied); screen.pendingWrap = owner.column + occupied > right && autoWrap
      }
      effect.lastPrinted = combined
      effect.repeatAttributes = PrintAttributes(style: cell.style, link: cell.link, protected: cell.protected)
      return
    }
    state.openCluster = nil; state.retainedScalars = 0
    let measuredWidth: Int
    let richText: String?
    if scalar.value < 0x80 && category == .other {
      measuredWidth = 1
      richText = nil
    } else {
      let text = String(scalar)
      measuredWidth = SwiftUnicode.cellWidth(of: text)
      richText = text
    }
    if measuredWidth == 0 {
      if SwiftUnicode.isDefaultIgnorable(scalar) {
        return
      }
      if !startsCluster, screen.cursorColumn > 0 {
        var attachment = screen.pendingWrap ? screen.cursorColumn : screen.cursorColumn - 1
        if !screen.pendingWrap, screen.rows[screen.cursorRow].kind(at: attachment) == 0, screen.cursorColumn < columns { attachment = screen.cursorColumn }
        let owner = Self.repairedCellOwner(in: screen.rows[screen.cursorRow], at: attachment)
        let count = screen.rows[screen.cursorRow].scalarCount(at: owner)
        if count + 1 > 64 { screen.rows[screen.cursorRow].addFlags(4, at: owner) }
        else { screen.rows[screen.cursorRow].appendScalar(scalar, at: owner) }
      }
      if !startsCluster { return }
    }
    let width = min(2, max(1, measuredWidth))
    state.capped = false
    if screen.pendingWrap && autoWrap { wrap() }
    guard screen.rows.indices.contains(screen.cursorRow),
          (0..<columns).contains(screen.cursorColumn) else { return }
    let bounds = writeBounds(screen.cursorColumn)
    if width == 2 && screen.cursorColumn + 2 > bounds.right + 1 && bounds.right > bounds.left && autoWrap {
      erase(screen.cursorRow, screen.cursorColumn..<(screen.cursorColumn + 1), attributes.style.erased())
      if bounds.left == 0 && bounds.right == columns - 1 { screen.rows[screen.cursorRow].setKind(4, at: screen.cursorColumn) }
      wrap()
    }
    let right = writeBounds(screen.cursorColumn).right
    let occupied = min(width, right + 1 - screen.cursorColumn)
    guard occupied > 0 else { return }
    if insertMode, (horizontal.0...horizontal.1).contains(screen.cursorColumn) {
      shift(screen.cursorRow, screen.cursorColumn, horizontal.1, occupied, attributes.style.erased())
    }
    let row = screen.cursorRow, column = screen.cursorColumn
    let truncated = width == 2 && occupied < width
    let kind: UInt8 = width == 2 && occupied == 2 ? 2 : 1
    let flags: UInt8 = (attributes.protected ? 2 : 0) | (truncated ? 1 : 0)
    if let richText {
      Self.replacePrintedLead(in: &screen.rows[row], at: column,
                              with: TerminalCell(text: richText, kind: kind, style: attributes.style,
                                                 link: attributes.link, flags: flags,
                                                 protected: attributes.protected))
    } else {
      Self.replacePrintedScalar(in: &screen.rows[row], at: column, scalar: scalar, kind: kind,
                                style: attributes.style, link: attributes.link, flags: flags,
                                protected: attributes.protected)
    }
    state.openCluster = (row, column); state.retainedScalars = 1
    effect.lastPrinted = richText ?? String(scalar)
    effect.repeatAttributes = PrintAttributes(style: attributes.style, link: attributes.link,
                                              protected: attributes.protected)
    screen.cursorColumn = min(right, column + occupied)
    screen.pendingWrap = column + occupied > right && autoWrap
  }

  // Printing replaces a single physical lead and, when needed, its adjacent
  // continuation.  Unlike erase/edit operations, the overwritten cells are
  // not observable mid-transaction, so install the rich lead directly and
  // clear only pair halves that survive beyond its new physical span.
  private static func replacePrintedLead(in row: inout TerminalRow, at column: Int,
                                         with lead: TerminalCell) {
    guard column >= 0, column < row.count else { return }
    let width = lead.kind == 2 ? 2 : 1
    guard column + width <= row.count else { return }
    guard preparePrintedReplacement(in: &row, at: column, count: width, like: lead) else { return }

    row.setCell(lead, at: column)
    if width == 2 {
      row.setCell(TerminalCell(text: "", kind: 3, style: lead.style,
                                link: lead.link, flags: lead.flags & ~UInt8(1),
                                protected: lead.protected), at: column + 1)
    }
    row.revision &+= 1
  }

  private static func replacePrintedScalar(in row: inout TerminalRow, at column: Int,
                                           scalar: Unicode.Scalar, kind: UInt8, style: TerminalStyle,
                                           link: String?, flags: UInt8, protected: Bool) {
    guard column >= 0, column < row.count else { return }
    let width = kind == 2 ? 2 : 1
    guard column + width <= row.count else { return }
    let prototype = TerminalCell(text: "", kind: kind, style: style, link: link,
                                 flags: flags, protected: protected)
    guard preparePrintedReplacement(in: &row, at: column, count: width, like: prototype) else { return }
    row.setScalar(scalar, at: column, kind: kind, style: style, link: link, flags: flags,
                  protected: protected)
    if width == 2 {
      row.setCell(TerminalCell(text: "", kind: 3, style: style, link: link,
                                flags: flags & ~UInt8(1), protected: protected), at: column + 1)
    }
    row.revision &+= 1
  }

  private static func replacePrintedASCII<C: Collection>(in row: inout TerminalRow, at column: Int,
                                                          scalars: C, count: Int,
                                                          attributes: borrowing PrintAttributes)
  where C.Element == Unicode.Scalar {
    guard count > 0, column >= 0, column < row.count, column + count <= row.count else { return }
    let prototype = TerminalCell(text: "", kind: 1, style: attributes.style, link: attributes.link,
                                 flags: attributes.protected ? 2 : 0, protected: attributes.protected)
    guard preparePrintedReplacement(in: &row, at: column, count: count, like: prototype) else { return }
    var destination = column
    for scalar in scalars {
      row.setScalar(scalar, at: destination, kind: 1, style: attributes.style,
                    link: attributes.link, flags: attributes.protected ? 2 : 0,
                    protected: attributes.protected)
      destination += 1
    }
    row.revision &+= UInt64(count)
  }

  // All print-time replacements share this boundary owner. It clears only
  // pair halves that survive outside the newly owned span; the caller writes
  // every cell inside that span directly.
  private static func preparePrintedReplacement(in row: inout TerminalRow, at column: Int,
                                                count: Int, like lead: borrowing TerminalCell) -> Bool {
    guard count > 0, column >= 0, column < row.count, column + count <= row.count else { return false }
    let end = column + count
    let eraseStyle = lead.style.erased()
    let clearsLeft = column > 0 && row.kind(at: column) == 3 && row.kind(at: column - 1) == 2
    let clearsRight = end < row.count && row.kind(at: end - 1) == 2 && row.kind(at: end) == 3
    if clearsLeft { row.erase(at: column - 1, style: eraseStyle) }
    if clearsRight { row.erase(at: end, style: eraseStyle) }
    return true
  }

  func hasValidInvariants(_ screen: TerminalScreen) -> Bool {
    guard columns > 0, rowCount > 0, screen.rows.count == rowCount,
          (0..<rowCount).contains(screen.cursorRow), (0..<columns).contains(screen.cursorColumn),
          screen.topMargin >= 0, screen.topMargin <= screen.bottomMargin, screen.bottomMargin < rowCount,
          screen.leftMargin >= 0, screen.leftMargin <= screen.rightMargin, screen.rightMargin < columns else {
      return false
    }
    return screen.rows.allSatisfy { row in
      guard row.count == columns else { return false }
      for index in 0..<row.count {
        switch row.kind(at: index) {
        case 2:
          guard index + 1 < row.count, row.kind(at: index + 1) == 3 else { return false }
        case 3:
          guard index > 0, row.kind(at: index - 1) == 2 else { return false }
        default: break
        }
      }
      return true
    }
  }

  // The text at a redrawable OSC 133 marker belongs to the shell. Before a
  // width reflow, retain terminal output before the marker and move the cursor
  // back to that exact boundary. A deferred-wrap marker starts on the next row.
  mutating func clearPromptSuffix(_ screen: inout TerminalScreen, eraseStyle: TerminalStyle) -> Bool {
    guard let anchor = screen.promptAnchor,
          let rowIndex = screen.rows.firstIndex(where: { $0.id == anchor.row }) else {
      screen.retirePromptAnchor()
      return false
    }
    if !anchor.pendingWrap {
      erase(&screen, row: rowIndex,
            columns: min(columns, max(0, anchor.column))..<columns,
            style: eraseStyle)
    }
    if rowIndex + 1 < screen.rows.count {
      for index in (rowIndex + 1)..<screen.rows.count {
        screen.rows[index] = eraseRow(eraseStyle)
      }
    }
    screen.cursorRow = rowIndex
    screen.cursorColumn = min(columns - 1, max(0, anchor.column))
    screen.pendingWrap = anchor.pendingWrap
    return true
  }

  // This is the rich editing seam. The caller selects a screen; document code
  // owns pair repair and rectangular copying so command handlers do not learn
  // about continuations, links, styles, protection, or row identities.
  mutating func shift(_ screen: inout TerminalScreen, row: Int, column: Int, right: Int,
                      count: Int, inserting: Bool, eraseStyle: TerminalStyle) {
    guard screen.rows.indices.contains(row), column <= right, right < columns else { return }
    let amount = min(count, right - column + 1); guard amount > 0 else { return }
    if inserting {
      if column + amount <= right {
        let original = screen.rows[row]
        for destination in stride(from: right, through: column + amount, by: -1) { screen.rows[row].copyCell(from: original, at: destination - amount, to: destination) }
      }
      for index in column..<(column + amount) { screen.rows[row].erase(at: index, style: eraseStyle) }
    } else {
      if column <= right - amount {
        let original = screen.rows[row]
        for destination in column...(right - amount) { screen.rows[row].copyCell(from: original, at: destination + amount, to: destination) }
      }
      for index in (right - amount + 1)...right { screen.rows[row].erase(at: index, style: eraseStyle) }
    }
    repairWidePairs(&screen.rows[row], eraseStyle: eraseStyle); screen.rows[row].revision &+= 1
  }
  mutating func erase(_ screen: inout TerminalScreen, row: Int, columns range: Range<Int>, style: TerminalStyle, selective: Bool = false) {
    guard screen.rows.indices.contains(row) else { return }
    let lower = max(0, range.lowerBound), upper = min(columns, range.upperBound); guard lower < upper else { return }
    for column in lower..<upper where !selective || !screen.rows[row].isProtected(at: column) { screen.rows[row].erase(at: column, style: style) }
    repairWidePairs(&screen.rows[row], eraseStyle: style); screen.rows[row].revision &+= 1
  }
  mutating func scrollRectangle(_ screen: inout TerminalScreen, top: Int, bottom: Int, left: Int, right: Int, count: Int, up: Bool, eraseStyle: TerminalStyle) {
    Self.scrollRectangleInPlace(&screen, columns: columns, top: top, bottom: bottom, left: left, right: right,
                                count: count, up: up, eraseStyle: eraseStyle)
  }
  private static func scrollRectangleInPlace(_ screen: inout TerminalScreen, columns: Int, top: Int, bottom: Int, left: Int, right: Int, count: Int, up: Bool, eraseStyle: TerminalStyle) {
    guard top >= 0, bottom < screen.rows.count, top <= bottom, left >= 0, right < columns, left <= right else { return }
    let amount = min(count, bottom - top + 1); guard amount > 0 else { return }
    let originals = screen.rows
    for step in 0...(bottom - top) {
      let destination = up ? top + step : bottom - step; let source = up ? destination + amount : destination - amount
      if source >= top && source <= bottom { screen.rows[destination].copyRange(from: originals[source], left...right) }
      else { for column in left...right { screen.rows[destination].erase(at: column, style: eraseStyle) }; screen.rows[destination].softWrapped = false }
      repairWidePairsInPlace(&screen.rows[destination], eraseStyle: eraseStyle); screen.rows[destination].revision &+= 1
    }
    if left != 0 || right != columns - 1 { screen.rows[top].softWrapped = false }
  }
  mutating func resize(_ screen: TerminalScreen, columns nextColumns: Int, rows nextRows: Int) -> TerminalScreen {
    var result = TerminalScreen(rows: [], columns: nextColumns); setSize(columns: nextColumns, rows: nextRows); result.rows = makeRows(nextRows)
    let start = max(0, screen.rows.count - nextRows)
    for (destination, source) in screen.rows.suffix(nextRows).enumerated() {
      var row = source; row.truncate(to: min(source.count, nextColumns))
      if row.count < nextColumns { row.appendBlanks(nextColumns - row.count) }
      repairWidePairs(&row, eraseStyle: TerminalStyle()); result.rows[destination] = row
    }
    result.cursorRow = min(nextRows - 1, max(0, screen.cursorRow - start)); result.cursorColumn = min(nextColumns - 1, screen.cursorColumn); result.pendingWrap = false
    return result
  }
  func repairedCellOwner(in row: TerminalRow, at column: Int) -> Int { Self.repairedCellOwner(in: row, at: column) }
  private static func repairedCellOwner(in row: TerminalRow, at column: Int) -> Int { column >= 0 && column < row.count && row.kind(at: column) == 3 && column > 0 ? column - 1 : column }
  private mutating func makeRows(_ count: Int) -> [TerminalRow] { (0..<count).map { _ in blankRow() } }
  private func repairWidePairs(_ row: inout TerminalRow, eraseStyle: TerminalStyle) {
    Self.repairWidePairsInPlace(&row, eraseStyle: eraseStyle)
  }
  private static func repairWidePairsInPlace(_ row: inout TerminalRow, eraseStyle: TerminalStyle) {
    repairWidePairsInPlace(&row, around: 0..<row.count, eraseStyle: eraseStyle)
  }
  // A cell mutation can only orphan a wide pair at the mutation's two edges:
  // cells wholly inside an overwritten span are erased, while an untouched
  // interior pair remains adjacent. Keep the full-row entry point above for
  // operations that replace arbitrary row regions, but scalar printing repairs
  // only the changed span and its crossing neighbours.
  private static func repairWidePairsInPlace(_ row: inout TerminalRow, around changed: Range<Int>, eraseStyle: TerminalStyle) {
    guard row.count > 0 else { return }
    let lower = max(0, changed.lowerBound)
    let upper = min(row.count, changed.upperBound)
    guard lower < upper else { return }
    let first = max(0, lower - 1)
    let last = min(row.count - 1, upper)
    for index in first...last {
      if row.kind(at: index) == 2 && (index + 1 >= row.count || row.kind(at: index + 1) != 3) { row.erase(at: index, style: eraseStyle) }
      if row.kind(at: index) == 3 && (index == 0 || row.kind(at: index - 1) != 2) { row.erase(at: index, style: eraseStyle) }
    }
  }
}
