# Fixed-capacity UTF-8 emission probe

This frozen, headless C-ABI probe isolates `a19f77f` from its direct parent
`f5dd5a9`. The source delta replaces the byte-fed decoder's per-byte pending
and scalar output arrays with a viable-prefix value state machine that emits
zero, one, or (after malformed-prefix rejection) two scalars. It is a backend
microbenchmark, not a full-app performance claim.

Both binaries used the same `-swift-version 5 -O` recipe, the unchanged
`tools/EmulatorComparison.c` driver, 160×50 geometry, zero history, a 64 KiB
maximum feed span, 2 MiB requested input, one warmup per side/workload, and
three alternating pairs. All four warmups and 12 timed samples passed exact
payload/reply FNV+byte gates and canonical final-state comparison.

| Workload | f5dd5a9 median MiB/s | a19f77f median MiB/s | Change |
| --- | ---: | ---: | ---: |
| ASCII | 2.451503 | 2.971472 | +21.21% |
| Mixed | 3.779404 | 4.277444 | +13.18% |

| Side | Commit | Binary bytes | SHA-256 | Build wall seconds |
| --- | --- | ---: | --- | ---: |
| Baseline | `f5dd5a9` | 616280 | `5611045aaa708f4ed922412d0d4a3fac4fdc94d84a5dc4f2f305cdbf64f06cc5` | 15.34 |
| Candidate | `a19f77f` | 619320 | `7024cd454fbd27b1ca50f2cbc9073557cd2c8cd5503a14de026fd92302667fbd` | 14.59 |

Build-wall values are provenance only; the recorded background included a
busy qemu process, so this short run is not a general compile benchmark.
`build/` retains exact invocations, clean frozen source lists and hashes,
inputs, compiler output, binary hashes and sizes. `run_decoder_probe.rb`
retains the runner, including owned process-group cleanup on interruption.
`logs/`, `snapshots/`, and `canonical/` retain every final raw/canonical
state. `attempt1-incomplete/` and `attempt2-incomplete/` preserve two
pre-timing runner setup failures separately; neither contains a timed sample.
