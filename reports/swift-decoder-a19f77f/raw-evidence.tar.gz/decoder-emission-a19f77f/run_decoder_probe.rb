#!/usr/bin/env ruby
# frozen_string_literal: true

# Frozen Swift-only f5dd5a9 -> a19f77f backend probe. The script is retained
# with its evidence: fixed labels, owned process-group timeout cleanup, and
# strict replay/canonical-state gates are independent of earlier probes.

require "digest"
require "fileutils"
require "json"
require "time"

raise "usage: #{$PROGRAM_NAME} REPORT_ROOT BASELINE_F5_BIN CANDIDATE_A19_BIN" unless ARGV.length == 3
root, baseline, candidate = ARGV
CANONICALIZER_SOURCE = File.expand_path("../canonicalizer-source.rb", __dir__)
require CANONICALIZER_SOURCE
baseline_label = ENV.fetch("BASELINE_LABEL", "Swift f5dd5a9 -O")
candidate_label = ENV.fetch("CANDIDATE_LABEL", "Swift a19f77f -O")

PROBE_WORKLOADS = %w[ascii mixed].freeze
SIDES = %w[baseline candidate].freeze
BYTES = 2 * 1024 * 1024
PAIRS = 3
TIMEOUT_SECONDS = 120.0
PROBE_STREAM_FIELDS = %w[payload_bytes payload_fnv1a64 reply_bytes reply_fnv1a64].freeze

def sha256(path) = Digest::SHA256.file(path).hexdigest

def run_harness(root, side, binary, workload, phase, pair = nil)
  tag = [phase, workload, ("pair#{pair}" if pair), side].compact.join("-")
  log = File.join(root, "logs", "#{tag}.log")
  snapshot = File.join(root, "snapshots", "#{tag}.json")
  started = Process.clock_gettime(Process::CLOCK_MONOTONIC)
  pid = nil
  status = nil
  begin
    pid = Process.spawn(binary, "--workload", workload, "--bytes", BYTES.to_s,
                        "--snapshot", snapshot, pgroup: true, out: log, err: "#{log}.stderr")
    loop do
      waited = Process.waitpid2(pid, Process::WNOHANG)
      if waited
        status = waited.last
        break
      end
      raise "#{tag}: timeout after #{TIMEOUT_SECONDS}s" if Process.clock_gettime(Process::CLOCK_MONOTONIC) >= started + TIMEOUT_SECONDS
      sleep 0.025
    end
  ensure
    # An interrupt or unexpected exception while waiting must not orphan the
    # owned harness process group. A reaped child has a non-nil `status`.
    if pid && status.nil?
      terminate_process_group(pid)
      Process.waitpid(pid) rescue Errno::ECHILD
    end
  end
  stderr = File.exist?("#{log}.stderr") ? File.read("#{log}.stderr") : ""
  raise "#{tag}: exit #{status.exitstatus}: #{stderr}" unless status.success?
  record = JSON.parse(File.read(log).strip)
  raise "#{tag}: unsupported driver protocol" unless record["protocol"] == 1
  raise "#{tag}: missing final snapshot" unless File.file?(snapshot)
  record.merge("implementation" => side, "phase" => phase, "pair" => pair,
               "wall_ns" => ((Process.clock_gettime(Process::CLOCK_MONOTONIC) - started) * 1_000_000_000).round,
               "snapshot_path" => snapshot, "snapshot_sha256" => sha256(snapshot))
end

def stream_gate(samples)
  failures, observed = [], {}
  PROBE_WORKLOADS.each do |workload|
    observed[workload] = SIDES.to_h do |side|
      records = samples.select { |sample| sample["workload"] == workload && sample["implementation"] == side }
      failures << "#{workload}/#{side}: expected #{PAIRS} samples, got #{records.length}" unless records.length == PAIRS
      records.each do |record|
        missing = PROBE_STREAM_FIELDS.reject { |field| record.key?(field) }
        failures << "#{workload}/#{side}/pair#{record["pair"]}: missing #{missing.join(",")}" unless missing.empty?
      end
      [side, records.map { |record| PROBE_STREAM_FIELDS.map { |field| record[field] } }.uniq]
    end
    failures << "#{workload}: payload/reply stream mismatch #{observed[workload].inspect}" unless observed[workload].values.flatten(1).uniq.length == 1
  end
  { "passed" => failures.empty?, "observed_stream_values" => observed, "failures" => failures }
end

def snapshot_gate(root, samples)
  mismatches = []
  FileUtils.mkdir_p(File.join(root, "canonical"))
  PROBE_WORKLOADS.each do |workload|
    PAIRS.times do |index|
      states = SIDES.to_h do |side|
        sample = samples.find { |item| item["workload"] == workload && item["implementation"] == side && item["pair"] == index + 1 }
        raise "#{workload}/#{side}/pair#{index + 1}: absent timed record" unless sample
        raw, projection = normalize_snapshot(File.read(sample.fetch("snapshot_path")))
        canonical = canonical_json(projection)
        path = File.join(root, "canonical", "sample-#{workload}-pair#{index + 1}-#{side}.json")
        File.write(path, canonical + "\n")
        [side, { "raw_sha256" => Digest::SHA256.hexdigest(JSON.generate(raw)), "canonical_sha256" => Digest::SHA256.hexdigest(canonical), "canonical_path" => path }]
      end
      mismatches << { "workload" => workload, "pair" => index + 1, "states" => states } unless states.values.map { |state| state.fetch("canonical_sha256") }.uniq.length == 1
    end
  end
  { "passed" => mismatches.empty?, "mismatches" => mismatches,
    "canonicalizer_source" => CANONICALIZER_SOURCE, "canonicalizer_sha256" => sha256(CANONICALIZER_SOURCE) }
end

FileUtils.mkdir_p(File.join(root, "logs"))
FileUtils.mkdir_p(File.join(root, "snapshots"))
result = {
  "protocol" => 1, "started_at_utc" => Time.now.utc.iso8601,
  "contract" => {
    "labels" => { "baseline" => baseline_label, "candidate" => candidate_label },
    "geometry" => [160, 50], "history_rows" => 0, "workloads" => PROBE_WORKLOADS,
    "requested_bytes" => BYTES, "max_feed_span" => 64 * 1024,
    "warmup_per_implementation" => 1, "alternating_pairs" => PAIRS,
    "timed_operations" => "feed, reply drain, pending-work drain, finish, reply drain, invariant validation, snapshot serialization/copy/free"
  },
  "binaries" => SIDES.to_h { |side|
    binary = side == "baseline" ? baseline : candidate
    [side, { "path" => File.realpath(binary), "sha256" => sha256(binary), "bytes" => File.size(binary) }]
  },
  "hardware" => hardware, "background_at_start" => background_activity,
  "warmups" => [], "samples" => []
}

begin
  PROBE_WORKLOADS.each do |workload|
    SIDES.each { |side| result["warmups"] << run_harness(root, side, side == "baseline" ? baseline : candidate, workload, "warmup") }
    PAIRS.times do |index|
      (index.even? ? SIDES : SIDES.reverse).each do |side|
        result["samples"] << run_harness(root, side, side == "baseline" ? baseline : candidate, workload, "sample", index + 1)
      end
    end
  end
  result["replay_gate"] = stream_gate(result.fetch("samples"))
  result["snapshot_gate"] = snapshot_gate(root, result.fetch("samples"))
  raise "correctness gate failed" unless result.dig("replay_gate", "passed") && result.dig("snapshot_gate", "passed")
  result["status"] = "complete"
rescue StandardError => error
  result["status"] = "incomplete"
  result["failure"] = { "class" => error.class.name, "message" => error.message }
  raise
ensure
  result["finished_at_utc"] = Time.now.utc.iso8601
  File.write(File.join(root, "result.json"), JSON.pretty_generate(result) + "\n")
end
