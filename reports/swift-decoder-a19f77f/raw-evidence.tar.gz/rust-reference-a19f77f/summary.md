# Archived Rust reference against Swift a19f77f

This separate same-contract reference run compares the immutable archived
Rust C-ABI binary from `b5a9fea` with Swift `a19f77f -O`. Rust was not rebuilt.
It uses the same 160×50/zero-history/64 KiB/2 MiB driver contract, one warmup
per side and three alternating pairs per workload. All 12 timed samples passed
strict payload/reply byte+FNV and canonical final-state gates.

| Workload | Archived Rust median MiB/s | Swift a19f77f median MiB/s | Swift vs Rust |
| --- | ---: | ---: | ---: |
| ASCII | 35.928574 | 2.897367 | -91.94% |
| Mixed | 20.592233 | 4.224177 | -79.49% |

The archived Rust binary path is
`/Users/helge/.codex/artifacts/terminal-emulator-comparison-20261108/binaries/rust-emulator-comparison`;
its verified SHA-256 is
`3b6eb607628b9c863cb917a2e0a80a34904692bb5ba8abbabff31fbb8a74b913`
(2438272 bytes). Swift candidate binary SHA-256 is
`7024cd454fbd27b1ca50f2cbc9073557cd2c8cd5503a14de026fd92302667fbd`
(619320 bytes). These reference samples are newly collected under this short
contract, and are not relabelled older 8 MiB numbers or a Rust rebuild.
