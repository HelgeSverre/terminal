require 'json'
require 'digest'
require 'fileutils'
require '/Users/helge/code/terminal/tools/native_smoke'

Signal.trap('TERM') { raise Interrupt, 'Profile terminated' }
Signal.trap('INT') { raise Interrupt, 'Profile interrupted' }
app = File.realpath(ARGV.fetch(0))
source = File.realpath(ARGV.fetch(1))
output = File.expand_path(ARGV.fetch(2))
abort 'Choose a new output' if File.exist?(output)
FileUtils.mkdir_p(output)
FileUtils.cp(__FILE__, File.join(output, 'runner.rb'))
executable = File.join(app, 'Contents/MacOS/Terminal')
extent = 64 * 1_048_576
report = File.join(output, 'cat.json')
result = { passed: false, executable_sha256: Digest::SHA256.file(executable).hexdigest,
           prefix_bytes: extent, scope: '64 MiB SQL prefix for primary-history profiling, not full-file acceptance.' }
process = sampler = nil
begin
  process = NativeSmokeProcess.new([executable, '--columns', '100', '--rows', '30', '--font-size', '14',
    '--history-limit', '10000', '--cat-smoke', report, extent.to_s,
    '--execute', '/usr/bin/head', '-c', extent.to_s, source], log: File.join(output, 'app-launch.log'))
  result[:pid] = process.pid
  raise 'App exited before sampling' if process.wait(3)
  sampler = NativeSmokeProcess.new(['/usr/bin/sample', process.pid.to_s, '5', '-file', File.join(output, 'sample.txt')],
                                   log: File.join(output, 'sample-launch.log'))
  status = sampler.wait(20)
  raise 'Sampler failed' unless status&.success?
  result[:sample_sha256] = Digest::SHA256.file(File.join(output, 'sample.txt')).hexdigest
  status = process.wait(180)
  raise 'App failed to finish prefix' unless status&.success?
  raise 'App left children' unless process.live_pids.empty?
  data = JSON.parse(File.read(report))
  raise 'Prefix checks failed' unless data.fetch('passed')
  result[:passed] = true
rescue StandardError, Interrupt => error
  result[:failure] = "#{error.class}: #{error.message}"
  raise
ensure
  result[:sampler_survivors] = sampler ? sampler.cleanup : []
  result[:app_survivors] = process ? process.cleanup : []
  result[:passed] = false unless result[:sampler_survivors].empty? && result[:app_survivors].empty?
  File.write(File.join(output, 'profile.json'), JSON.pretty_generate(result) + "\n")
end
puts 'PASS prefix profile; all owned processes exited'
