import Foundation

@main enum DefaultHistoryCapProbe {
  static func main() throws {
    let core = terminal_create(4_096, 1)!
    defer { terminal_destroy(core) }
    let limit: UInt64 = 64 * 1_048_576
    let bytes = Array((String(repeating: "x", count: 4_096) + "\r\n").utf8)
    var largest: UInt64 = 0
    var lines = 0
    for _ in 0..<500 {
      let consumed = bytes.withUnsafeBufferPointer { terminal_feed(core, $0.baseAddress, $0.count, 0) }
      guard consumed == bytes.count else { exit(2) }
      lines += 1
      largest = max(largest, terminal_history_bytes(core))
      if largest > limit { break }
    }
    let result: [String: Any] = ["within_default_64_mib": largest <= limit,
                               "largest_history_bytes": largest, "lines": lines]
    print(String(decoding: try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys]), as: UTF8.self))
    exit(largest <= limit && lines == 500 ? 0 : 3)
  }
}
