import Foundation

@main struct GeometryTests {
  static func main() {
    for (w, h) in [(9, 21), (18, 42), (1, 1)] {
      for code in UInt32(0x2580)...0x259f {
        let text = String(UnicodeScalar(code)!)
        guard let shapes = GeometricGlyph.rectangles(text: text, width: w, height: h) else {
          preconditionFailure("missing block")
        }
        for rect in shapes {
          precondition(
            rect.x >= 0 && rect.y >= 0 && rect.width >= 0 && rect.height >= 0
              && rect.x + rect.width <= w && rect.y + rect.height <= h)
        }
      }
      let halves =
        GeometricGlyph.rectangles(text: "▀", width: w, height: h)! + GeometricGlyph.rectangles(
          text: "▄", width: w, height: h)!
      for y in 0..<h {
        for x in 0..<w {
          let coverage = halves.filter {
            x >= $0.x && x < $0.x + $0.width && y >= $0.y && y < $0.y + $0.height
          }.count
          precondition(coverage == 1, "gap/overlap at \(x),\(y)")
        }
      }
    }
    let horizontal = GeometricGlyph.rectangles(text: "─", width: 9, height: 21)!
    precondition(horizontal.contains { $0.x == 0 })
    precondition(horizontal.contains { $0.x + $0.width == 9 })
    precondition(GeometricGlyph.rectangles(text: "a", width: 9, height: 21) == nil)
    precondition(GeometricGlyph.rectangles(text: "é", width: 9, height: 21) == nil)
    print(
      "PASS geometry: all block characters stay in bounds; half blocks tile odd/even cells without gaps; box strokes meet cell edges"
    )
  }
}
