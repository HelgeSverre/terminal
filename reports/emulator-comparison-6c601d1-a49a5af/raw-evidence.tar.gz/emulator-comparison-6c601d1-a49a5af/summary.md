# Frozen Swift vs Rust emulator comparison

These are scoped results for the current frozen implementations, not a generic terminal-core or full-product comparison.
Replay payload/reply gate: **PASS**. Canonical final-snapshot gate: **PASS**.

| Implementation | Recorded headless-recipe build wall seconds (not matched app compile) | Executable bytes | SHA-256 |
| --- | ---: | ---: | --- |
| swift | 15.833492994308472 | 600400 | eda0cc44955325894c24d6ffb23d0b0ad07d62c30dadac6759c184282fa41faf |
| rust | 5.614658 | 2438272 | 3b6eb607628b9c863cb917a2e0a80a34904692bb5ba8abbabff31fbb8a74b913 |

| Workload | Swift median MiB/s | Rust median MiB/s |
| --- | ---: | ---: |
| ascii | 2.53 | 39.60 |
| mixed | 1.28 | 22.06 |

See `result.json` for every runtime/RSS sample and `snapshots/` for every raw final ABI JSON snapshot.
